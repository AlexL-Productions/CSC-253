﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class ProductionWorker : Employee
    {
        // numeric variables for shift and hourly payrate 
        private int _shift;
        private decimal _hourlyPay;

        // Constructor
        public ProductionWorker()
        {
            this._shift = 0;
            this._hourlyPay = 0;
        }

        // Shift property
        public int Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        // Hourly Pay property
        public decimal HourlyPay
        {
            get { return _hourlyPay; }
            set { _hourlyPay = value; }
        }
    }
}
