﻿/**
* 10/31/2018
* CSC 253
* Alex Lopez
* ShiftSupervisor Class
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    class Program
    {
        // Method that accepts an object and assigns input values to its variables
        private static void CreateEmployeeProfile(ShiftSupervisor supervisor)
        {
            Console.WriteLine("Enter your full name: ");

             supervisor.Name = Console.ReadLine();

            Console.WriteLine("Enter your ID number: ");

            supervisor.Number = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your annual salary: ");

            supervisor.Salary = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Enter your annual bonus amount: ");

            supervisor.Bonus = decimal.Parse(Console.ReadLine());
        }

        // Method that accepts an object and displays the values of its variables
        private static void DisplayData(ShiftSupervisor supervisor)
        {
            Console.WriteLine("\nProfile Created: \n\nName: {0} \nID Number: {1} \nAnnual Salary: {2} \nAnnual Bonus: {3}",
                supervisor.Name, supervisor.Number, supervisor.Salary.ToString("c"), supervisor.Bonus.ToString("c"));
        }

        public static void Main(string[] args)
        {
            // Instantiate a ShiftSupervisor object
            ShiftSupervisor supervisor = new ShiftSupervisor();

            // Call the method to create the employee's profile
            CreateEmployeeProfile(supervisor);

            // Display the employees data
            DisplayData(supervisor);

            // Keep the console open
            Console.ReadLine();
        }
    }
}
