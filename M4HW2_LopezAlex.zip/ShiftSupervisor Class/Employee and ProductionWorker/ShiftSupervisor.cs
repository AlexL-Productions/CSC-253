﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class ShiftSupervisor : Employee
    {
        // Fields
        private decimal _salary;
        private decimal _bonus;

        // Constructor
        public ShiftSupervisor()
        {
            this._salary = 0;
            this._bonus = 0;
        }

        // Salary property
        public decimal Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }

        // Bonus property
        public decimal Bonus
        {
            get { return _bonus; }
            set { _bonus = value; }
        }
    }
}
