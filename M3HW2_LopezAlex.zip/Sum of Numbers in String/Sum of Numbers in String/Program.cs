﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 10/24/2018
* CSC 253
* Alex Lopez
* Sum of Numbers in a string
*/

namespace Sum_of_Numbers_in_String
{
    class Program
    {
        static void Main(string[] args)
        {
            // accumulator for the total amount
            int total = 0;

            Console.WriteLine("Enter a series of numbers separated by commas or spaces: ");

            // get input 
            string userInput = Console.ReadLine();

            try
            {
                // tokenize the string
                string[] tokens = userInput.Split(new char[] { ',', ' ' });

                // add each number in the array and get the sum
                foreach (string s in tokens)
                {
                    total += int.Parse(s);
                }

                // display the sum of numbers
                Console.WriteLine("The total of numbers is: {0}", total);

                // keep the console open
                Console.Read();
            }
            catch(Exception ex)
            {
                // display error exception
                Console.WriteLine(ex);

                Console.Read();
            }
        }
    }
}
