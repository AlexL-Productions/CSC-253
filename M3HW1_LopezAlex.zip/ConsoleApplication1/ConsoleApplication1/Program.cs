﻿/**
* 10/20/2018
* CSC 253
* Alex Lopez
* This program accepts a message and returns
* the number of words it contains
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        // method to get the number of words in a sentence
        static void CountWords(string s)
        {
            int wordsCount = 0;
            
            // split the sentence
            string[] Tokens = s.Split(null);

            foreach (String i in Tokens)
            {
                if (char.IsLetter(s, 0))
                {
                    wordsCount++;
                }
            }

            // display the number or words
            Console.WriteLine("there are " + wordsCount + " words in the sentence");
        }

        public static void Main(string[] args)
        {
            Console.WriteLine("enter a sentence to find the number of words it contains");

            // get user input
            string input = Console.ReadLine();

            // call the method to get number of words
            CountWords(input);

            // keep the console open
            Console.ReadLine();
        }
    }
}
