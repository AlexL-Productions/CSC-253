﻿namespace Kinetic_Energy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.MassPromptLabel = new System.Windows.Forms.Label();
            this.VelocityPromptLabel = new System.Windows.Forms.Label();
            this.MassTextBox = new System.Windows.Forms.TextBox();
            this.VelocityTextBox = new System.Windows.Forms.TextBox();
            this.KineticEnergyLabel = new System.Windows.Forms.Label();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(95, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(518, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "To find the Kinetic Energy of an object identify its Mass and Velocity";
            // 
            // MassPromptLabel
            // 
            this.MassPromptLabel.AutoSize = true;
            this.MassPromptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MassPromptLabel.Location = new System.Drawing.Point(112, 121);
            this.MassPromptLabel.Name = "MassPromptLabel";
            this.MassPromptLabel.Size = new System.Drawing.Size(173, 16);
            this.MassPromptLabel.TabIndex = 1;
            this.MassPromptLabel.Text = "Enter the object\'s Mass:";
            // 
            // VelocityPromptLabel
            // 
            this.VelocityPromptLabel.AutoSize = true;
            this.VelocityPromptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VelocityPromptLabel.Location = new System.Drawing.Point(112, 168);
            this.VelocityPromptLabel.Name = "VelocityPromptLabel";
            this.VelocityPromptLabel.Size = new System.Drawing.Size(235, 16);
            this.VelocityPromptLabel.TabIndex = 2;
            this.VelocityPromptLabel.Text = "Enter the object\'s Velocity (mph):";
            // 
            // MassTextBox
            // 
            this.MassTextBox.Location = new System.Drawing.Point(376, 121);
            this.MassTextBox.Name = "MassTextBox";
            this.MassTextBox.Size = new System.Drawing.Size(100, 20);
            this.MassTextBox.TabIndex = 3;
            // 
            // VelocityTextBox
            // 
            this.VelocityTextBox.Location = new System.Drawing.Point(376, 168);
            this.VelocityTextBox.Name = "VelocityTextBox";
            this.VelocityTextBox.Size = new System.Drawing.Size(100, 20);
            this.VelocityTextBox.TabIndex = 4;
            // 
            // KineticEnergyLabel
            // 
            this.KineticEnergyLabel.AutoSize = true;
            this.KineticEnergyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KineticEnergyLabel.Location = new System.Drawing.Point(213, 219);
            this.KineticEnergyLabel.Name = "KineticEnergyLabel";
            this.KineticEnergyLabel.Size = new System.Drawing.Size(119, 16);
            this.KineticEnergyLabel.TabIndex = 5;
            this.KineticEnergyLabel.Text = "Kinetic Energy =";
            // 
            // OutputLabel
            // 
            this.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLabel.Location = new System.Drawing.Point(376, 212);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(100, 23);
            this.OutputLabel.TabIndex = 6;
            this.OutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalculateButton
            // 
            this.CalculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateButton.Location = new System.Drawing.Point(216, 271);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(106, 33);
            this.CalculateButton.TabIndex = 7;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(370, 271);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(106, 33);
            this.ExitButton.TabIndex = 8;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 374);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.OutputLabel);
            this.Controls.Add(this.KineticEnergyLabel);
            this.Controls.Add(this.VelocityTextBox);
            this.Controls.Add(this.MassTextBox);
            this.Controls.Add(this.VelocityPromptLabel);
            this.Controls.Add(this.MassPromptLabel);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label MassPromptLabel;
        private System.Windows.Forms.Label VelocityPromptLabel;
        private System.Windows.Forms.TextBox MassTextBox;
        private System.Windows.Forms.TextBox VelocityTextBox;
        private System.Windows.Forms.Label KineticEnergyLabel;
        private System.Windows.Forms.Label OutputLabel;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

