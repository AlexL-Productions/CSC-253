﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 8/31/2018
* CSC 253
* Alex Lopez
* This program will calculate an objects kinetic energy
*/

namespace Kinetic_Energy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // method that accepts two parameters and returns the caclulation
        public double KineticEnergy(double mass, double velocity)
        {
            velocity *= 0.44704;

            return ((0.5 * mass) * (Math.Pow(velocity, 2)));
        }
        
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // variables to calculate kinetic energy
            double mass, velocity, energy;

            // Test for accurate input and convert it to double
            if (double.TryParse(MassTextBox.Text, out mass))
            {
                if(double.TryParse(VelocityTextBox.Text, out velocity))
                {
                    // call and pass arguments to the KineticEnergy method
                    // assign the value to the appropriate variable
                    energy = KineticEnergy(mass, velocity);

                    // display the value to the label
                    OutputLabel.Text = energy.ToString("n2") + " Joules";
                }
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // close the program
            this.Close();
        }
    }
}
