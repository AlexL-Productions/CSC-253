﻿/**
* 10/5/2018
* CSC 253
* Alex Lopez
* This program simiulates a tic tac toe game. 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // method to search for matching values in the labels
        private void CheckForWinner()
        {
            // serach all rows
            if (label1.Text == label2.Text && label2.Text == label3.Text)
            {
                resultLabel.Text = label3.Text + " Wins!!!";
            }
            if (label4.Text == label5.Text && label5.Text == label6.Text)
            {
                resultLabel.Text = label6.Text + " Wins!!!";
            }
            if (label7.Text == label8.Text && label8.Text == label9.Text)
            {
                resultLabel.Text = label9.Text + " Wins!!!";
            }

            // search all colums
            if (label1.Text == label4.Text && label4.Text == label7.Text)
            {
                resultLabel.Text = label7.Text + " Wins!!!";
            }
            if (label2.Text == label5.Text && label5.Text == label8.Text)
            {
                resultLabel.Text = label8.Text + " Wins!!!";
            }
            if (label3.Text == label6.Text && label6.Text == label9.Text)
            {
                resultLabel.Text = label9.Text + " Wins!!!";
            }

            // serch diagonally 
            if (label1.Text == label5.Text && label5.Text == label9.Text)
            {
                resultLabel.Text = label9.Text + " Wins!!!";
            }
            if (label3.Text == label5.Text && label5.Text == label7.Text)
            {
                resultLabel.Text = label7.Text + " Wins!!!";
            }

            // if there is no winner declare the game a draw
            if (resultLabel.Text == "O" || resultLabel.Text == "X")
            {
                resultLabel.Text = "Draw!!!";
            }
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            // rendom object 
            Random rand = new Random();

            // assign a value of 1 or 0 to all the labels and convert them to strings
            for (int i = 0; i < 9; i++)
            {
                foreach (Control Ctrl in this.Controls)
                {
                    if (Ctrl is Label)
                    {
                        ((Label)Ctrl).Text = rand.Next(2).ToString();

                        if ((Ctrl as Label).Text == "0")
                        {
                            ((Label)Ctrl).Text = "O";
                        }
                        if ((Ctrl as Label).Text == "1")
                        {
                            ((Label)Ctrl).Text = "X";
                        }
                    }
                }
            }
            // call the method to find a winner
            CheckForWinner();
        }
    }
}
