﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_Info_Book
{
    class PersonEntry
    {
        public string _name { get; set; }
        public string _email { get; set; }
        public int _phone { get; set; }
        public int _age { get; set; }

        public PersonEntry(string n, string e, int p, int a)
        {
            this._name = n;
            _email = e;
            _phone = p;
            _age = a;
        }
    }
}
