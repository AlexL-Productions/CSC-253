﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Person_Info_Book
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //public 
        private void submitButton_Click(object sender, EventArgs e)
        {
            // variables to hold the persons name, email. phone, and age
            string name, email;
            int phone, age;

            // open the file
            StreamReader inputFile = File.OpenText("C:/Users/lopeza1328/Downloads/People.txt");

            // read the contents of the file
            while (!inputFile.EndOfStream)
            {
                // instantiate 4 PersonEntry objects
                PersonEntry[] people = new Person_Info_Book.PersonEntry[4];

                name = inputFile.ReadLine();

                // add the contents to the listBox
                listBox1.Items.Add(name);
            }
        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            // close this form
            this.Close();
        }

        
    }
}

