﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class BattleResult
    {
        // Class variables
        //public int numRoll { get; set; }
        private int _diceResult1;
        private int _diceResult2;
        private int _sumOfRoll;

        RandomNumber rand = new RandomNumber();

        public BattleResult()
        {
            
        }
        // field varialbe accessor
        public int DiceResult1
        {
            get { return _diceResult1; }
            set { _diceResult1 = value; }
        }
        // field variable accessor
        public int DiceResult2
        {
            get { return _diceResult2; }
            set { _diceResult2 = value; }
        }
        public int SumOfRoll
        {
            get { return _sumOfRoll; }
            set { _sumOfRoll = value; }
        }
        // Method to determin dice roll value
        public int Roll()
        {
            _diceResult1 = rand.GetRandomNum(1, 7);
            _diceResult2 = rand.GetRandomNum(1, 7);

            //_sumOfRoll = _diceResult1 + _diceResult2;

            if (DiceResult1 == 1 || DiceResult2 == 1)
            {
                SumOfRoll = 0;
            }
            else
            {
                SumOfRoll = DiceResult1 + DiceResult2;

                if ( SumOfRoll == 12)
                {
                    SumOfRoll += BonusRoll();
                }
            }
            

            return SumOfRoll;
        }
        // The BonusRoll method lets the user roll the dice one more time
        // if they manage to rolle two sixes in their current turn
        public int BonusRoll()
        {
            // local int to hold a bonus roll 
            int bonusRoll = rand.GetRandomNum(1, 7);

            return SumOfRoll + bonusRoll;
        }
    }
}
