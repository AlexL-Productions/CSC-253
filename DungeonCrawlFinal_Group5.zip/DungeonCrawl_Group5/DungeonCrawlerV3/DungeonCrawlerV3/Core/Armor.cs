﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    class Armor
    {
        // Properties for Armor Class
        public string Name { get; set; }
        public string Description { get; set; }
        public int OriginalArmor { get; set; }
        public int CurrentArmor { get; set; }

        public Armor(string name, string description, int origArmor, int currArmor)
        {
            this.Name = name;
            this.Description = description;
            this.OriginalArmor = origArmor;
            this.CurrentArmor = currArmor;
        }
    }
}
