﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
   public  class StandardMessages
    {
        public static void DisplayMenu()
        {
            // Display these standard messages (game instructions) to the user after player creation
            Console.WriteLine("-------Main Menu-------");
            Console.WriteLine("To see all the rooms types rooms.");
            Console.WriteLine("To see all the mobs types mobs.");
            Console.WriteLine("To see all the races type races.");
            Console.WriteLine("To see all the weapons type weapons.");
            Console.WriteLine("To see all the potions type potions.");
            Console.WriteLine("To see all the treasures type treasure. ");
            Console.WriteLine("To go north or south type north or south.");
            Console.WriteLine("To exit the game type exit.");
        }
    }
}
