﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Core
{
   public static class ListBuilder
    {
        private static string[] GetNextLine(StreamReader input)
        {
            string[] line = input.ReadLine().Split(',');
            return line;
        }

        public static void Build()
        {
            #region Build Room
            using (StreamReader reader = File.OpenText("rooms.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] line = GetNextLine(reader); 
                    World.rooms.Add(new Room(line[0], line[0]));
                }
            }
            #endregion

            #region Build Weapon
            using (StreamReader reader = File.OpenText("weapons.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] line = GetNextLine(reader);
                    World.weapons.Add(new Weapon(line[0]));
                }
            }
            #endregion

            #region Build Potion
            using (StreamReader reader = File.OpenText("potions.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] line = GetNextLine(reader);
                    World.potions.Add(new Potion(line[0]));
                }
            }
            #endregion

            #region Build Treasure
            using (StreamReader reader = File.OpenText("treasures.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] line = GetNextLine(reader);
                    World.treasures.Add(new Treasure(line[0], line[0]));
                }
            }
            #endregion
            World.players.Add(new Player());
        }
    }
}
