﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Core
{
    public class Player
    {
        /*
         * Constructor
         * Creates a new object from the Player class. 
         * The player has a list to contain instances of the armor
         * class, weapon class, stats of int data type
         * for a starting HP
         */

        public Player()
        {
            this.WeaponsBag = new List<Weapon>();
            this.PotionsBag = new List<Potion>();
            //  this.ArmorsBag = new List<Armor>();
            //  this.ClassSelect = new List<Classes>();
            // this.RaceSelect = new List<Race>();
            this.OriginalHP = 100;
            this.CurrentHP = 100;
            this.OriginalArmor = 4;
            this.CurrentArmor = 4;
        }

        // Properties for the player class
        public static string Name { get; set; }
        public static string Password { get; set; }
        public static string Class { get; set; }
        public static string Race { get; set; }
        public int CurrentLocation { get; set; }
        public int OriginalHP { get; set; }
        public int CurrentHP { get; set; }
        public int OriginalArmor { get; set; }
        public int CurrentArmor { get; set; }
        public int attackDamage { get; set;}
        public int defenseStat { get; set; }

        public Weapon EquippedWeapon { get; set; }
        // public Armor EquippedArmor { get; set; }
        public Potion EquippedPotion { get; set; }

        // public List<Armor> ArmorsBag { get; set; }
        public List<Weapon> WeaponsBag { get; set; }
        public List<Potion> PotionsBag { get; set; }

        // Method for the player class
        public void ShowStats()
        {
            Console.WriteLine("*****" + Name + "*****");
            Console.WriteLine("Current Location: " + this.CurrentLocation);
            Console.WriteLine("Original HP: " + this.OriginalHP);
            Console.WriteLine("Current HP: " + this.CurrentHP);
            Console.WriteLine("Original Armor: " + this.OriginalArmor);
            Console.WriteLine("Current Armor: " + this.CurrentArmor);
        }
    }
}
