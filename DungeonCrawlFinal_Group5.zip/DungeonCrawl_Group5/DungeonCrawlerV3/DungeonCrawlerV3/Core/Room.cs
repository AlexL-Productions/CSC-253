﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Room
    {
        // Properties for Room Class
        public string Name { get; set; }
        public string Description { get; set; }

        public Room(string name, string description)
        {
            this.Name = name;
            this.Description = description;
        }
    }
}
