﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Combat:Weapon
    {
        // Instantiated objects that will be used to retrieve its values
        BattleResult playerRoll = new BattleResult();
        BattleResult enemyRoll = new BattleResult();
        Player player = new Player();
        Mob monster = new Mob();

        // bool variables for testing loops
        public bool playerTurn { get; private set; } = false;
        public bool enemyTurn { get; private set; } = false;
        public bool isAlive = true;

        // field variables to hold the player's and monster's attack and defense attribute
        public int pDamage { get; set;}
        public int mDamage { get; private set; }

        // The BeginBattle() method calls the Fight() method while either character is alive 
        // user input is accpeted for validation
        public bool BeginBattle(string input)
        {
            // the method executes as long as either player or monster is alive
            while (isAlive)
            {
                Fight();
            }
            // returns false if either player or monster is defeated
            return false;
        }

        // The Fight() method executes the combat sequence.
        // The player will roll first and apply damage. 
        // The monster will follow through unless it is defeated first
        public  bool Fight()
        {
            do
            {    
                 // player rolls dice
                playerRoll.Roll();
                // get total values from the dice rolled
                pDamage = playerRoll.SumOfRoll;
                // get damage amount from weapon modifier
                player.attackDamage = (pDamage * WeaponDamage);
                // Display the players actions
                if (monster.CurrentHP > 0 && isAlive) 
                {
                    Console.WriteLine("Players Turn>>>");

                    if (player.attackDamage == 0)
                    {
                        Console.WriteLine("Player attack misses!!!");
                    }

                    else
                    {
                        Console.WriteLine("Monster HP: {0}/{1}", monster.OriginalHP, monster.CurrentHP);

                        Console.WriteLine("Player {0} does {1} damage to Monster!!!", Player.Name, player.attackDamage);
                    }
                    // Apply damage (if any) to monsters health
                    monster.CurrentHP -= player.attackDamage;

                    if (monster.CurrentHP <= 0)
                    {
                        isAlive = false;

                        Console.WriteLine("Monster is defeated!!!");

                        return false;
                    }
                    // Display the monsters HP after players turn
                    Console.WriteLine("Monster HP: {0}/{1}", monster.OriginalHP, monster.CurrentHP);

                    Console.WriteLine(">>>End of Players Turn\n=>");

                    Console.ReadLine();



                    // enemy rolls dice
                    enemyRoll.Roll();
                    // total values from dice rolled
                    mDamage = enemyRoll.SumOfRoll;
                    // damage from monster attack modifier
                    monster.attackDamage = monster.attackStat * mDamage;
                    // Display the monster's action
                    if (player.CurrentHP > 0 && isAlive)   
                    {
                        Console.WriteLine(">>>Monsters Turn");

                        if (monster.attackDamage == 0)
                        {
                            Console.WriteLine("Monster attack misses!!!");
                        }

                        else
                        {
                            Console.WriteLine("Player HP: {0}/{1}", player.OriginalHP, player.CurrentHP);

                            Console.WriteLine("Monster does {0} damage to Player!!!", monster.attackDamage, Player.Name);
                        }
                        // Apply damage (if any) to players health
                        player.CurrentHP -= monster.attackDamage;

                        if (player.CurrentHP <= 0)
                        {
                            isAlive = false;

                            Console.WriteLine("Player is defeated!!!");

                            return true;
                        }
                        // Display the players HP after monster's turn
                        Console.WriteLine("Player HP: {0}/{1}", player.OriginalHP, player.CurrentHP);

                        Console.WriteLine(">>>End of Monsters turn...\n=>");

                        Console.ReadLine();
                    }
                }
            }
            while (isAlive);

            return true;
        }

        // The EnemyTurn method accpets a player object and BattleResult object
        // this is the enemys turn and their attack damage will be calculated
        //public bool EnemyTurn()                                                   // EnemyTurn method not used because it would not execute 
        //{
        //    // enemy rolls dice
        //    enemyRoll.Roll();
        //    // total values from dice rolled
        //    mDamage = enemyRoll.SumOfRoll;
        //    // damage from monster attack modifier
        //    monster.attackDamage = monster.attackStat * mDamage;

        //    while (player.CurrentHP > 0 && isAlive)
        //    {
        //        Console.WriteLine(">>>Monsters Turn");

        //        Console.WriteLine("Monster does {0} damage to Player!!!", monster.attackDamage, Player.Name);

        //        player.CurrentHP -= monster.attackDamage;

        //        if (player.CurrentHP <= 0)
        //        {
        //            isAlive = false;

        //            Console.WriteLine("Player is defeated!!!");
        //            return true;
        //        }

        //        Console.WriteLine("Player HP: {0} / {1}", player.OriginalHP, player.CurrentHP);

        //        Console.WriteLine(">>>End of Monsters turn...\n=>");

        //        Console.ReadLine();
        //    }
        //    return true;
        //}
    }
}
