﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
   public  class WelcomeScreen
    {
        public static void Welcome()
        {
            // Display Welcome Screen and first instructions to the player
            Console.WriteLine("Welcome To The MUD Game");

            Console.WriteLine("\nTo create a new player type 'new'. To load your profile type 'load'");        }
    }
}
