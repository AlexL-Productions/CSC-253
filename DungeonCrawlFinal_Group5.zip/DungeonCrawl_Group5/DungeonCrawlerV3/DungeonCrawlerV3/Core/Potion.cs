﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Potion
    {
        // Properties for Potion Class
        /*
         * Commented out int properties for now to prevent crash
         */ 
        public string Name { get; set; }
        //public int  CurrentHP { get; set; }
        //public int CurrentMana { get; set; }

        public Potion(string name)
        {
            this.Name = name;
           // this.CurrentHP = currentHP;
           // this.CurrentMana = CurrentMana;
        }
    }
}
