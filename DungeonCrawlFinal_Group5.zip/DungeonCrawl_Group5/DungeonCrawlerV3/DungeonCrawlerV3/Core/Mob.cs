﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Mob : RandomNumber
    {
        // RandomNumber object
        RandomNumber rand = new RandomNumber();


        // Properties for Mob Class
        public string Name { get; set; }
        public string Description { get; set; }

        public const int originalHP = 50;

        //public readonly int CurrentHP = 50;
        public int CurrentHP { get; set; } = 50;
        public int OriginalArmor { get; set; }
        public int CurrentArmor { get; set; }
        public int attackStat { get; set; } = 2;
        public int defenseStat { get; set; } = 2;
        public int attackDamage { get; set; }
        public bool isEncountered { get; set; } = false;
        private int _currentLocation;
        

        public Mob()
        {
            
        }
        public Mob(string name, string description, int origHP, int currHP, int origArmor, int currArmor, int atkstat, int defstat, int atkdmg)
        {
            this.Name = name;
            this.Description = description;
            //this.OriginalHP = origHP;
            this.CurrentHP = currHP;
            this.OriginalArmor = origArmor;
            this.CurrentArmor = CurrentArmor;
            this.attackStat = atkstat;
            this.defenseStat = defstat;
            this.attackDamage = atkdmg;
        }
        public int OriginalHP
        {
            get { return originalHP; }
            set { value = originalHP; }
        }
        public int CurrentLocation
        {
            get { return rand.GetRandomNum(1, 7); }
            set { value = _currentLocation; }
        }

    }
}
