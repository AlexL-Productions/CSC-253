﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class World
    {
        public static List<Room> rooms = new List<Room>();
        public static List<Treasure> treasures = new List<Treasure>();
        public static List<Weapon> weapons = new List<Weapon>();
        public static List<Potion> potions = new List<Potion>();
        public static List<Mob> mobs = new List<Mob>();
        public static List<Player> players = new List<Player>();
    }
}
