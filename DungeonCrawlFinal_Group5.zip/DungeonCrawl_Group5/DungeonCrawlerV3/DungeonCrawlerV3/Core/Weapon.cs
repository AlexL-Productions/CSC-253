﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
   public class Weapon
    {
        private static int _weaponDamage = 4;
        public string Name { get; set; }
        // Properties for Weapon Class
        public Weapon(string name)
        {
            this.Name = name;
            //this.Strength = strength;
        }
        // no-args constructor
        public Weapon()
        {

        }
        // Getter and setter for baseDamage
        public int WeaponDamage
        {
            get { return _weaponDamage; }
            set { _weaponDamage = value; }
        }      
    }
}