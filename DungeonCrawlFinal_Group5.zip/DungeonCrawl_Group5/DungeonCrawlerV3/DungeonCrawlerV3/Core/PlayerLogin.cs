﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Core
{
    public class PlayerLogin
    {
        public static bool LoadProfile(string input)
        {
            switch (input.ToLower())
            {
                // Create a new player profile for player
                case "new":
                    CreatNewProfile();

                    return true;
                    // Load case for existing player profile
                case "load":
                    if (File.Exists("PlayerProfile.txt"))
                    {
                        Console.WriteLine("Enter your existing password");

                        Player.Password = Console.ReadLine();

                        using (StreamReader reader = File.OpenText("PlayerProfile.txt"))
                        {
                            string[] textInFile = reader.ReadLine().Split(',');

                            if (textInFile[0] == Player.Password)
                            {
                                Console.WriteLine("\nLogin Successful!!");
                                return true;
                            }
                            else
                            {
                                Console.WriteLine("That password doesn't match.");
                                LoadProfile(input);
                            }
                        }
                    }
                    else
                    {
                        // If no player profile exist, prompt to create a profile
                        Console.WriteLine("No profile found. Would you like to create a new Character?: \ntype 'yes' to create new profile");

                        string answer = Console.ReadLine().ToLower();

                        if (answer == "yes")
                        {
                            CreatNewProfile();
                        }
                        else
                        {
                            return false;
                        }
                    }
                    return true;
            }
            return true;
        }

        public static bool Validate(string input)
        {
           // Validate the player provided password
            if(NumUpperCase(input) >= 1 && NumLowerCase(input) >= 1 && NumSpecialChar(input) >= 1)
            {
                return true;
            }
            else
            {
                Console.WriteLine("The password does not meet the requirements.\n");
                //CreatNewProfile();
                return false;
            }
        }
        public static int NumUpperCase(string input)
        {
            int uppercase = 0;
            foreach(char ch in input)
            {
                if(char.IsUpper(ch))
                {
                    uppercase++;
                }
            }
            return uppercase;
        }
        public static int NumLowerCase(string input)
        {
            int lowercase = 0;
            foreach (char ch in input)
            {
                if (char.IsUpper(ch))
                {
                    lowercase++;
                }
            }
            return lowercase;
        }
        public static int NumSpecialChar(string input)
        {
            int numSpecialChar = 0;

            string specialChar = @"\|!#$%&/()=?>><<@";

            foreach (var item in specialChar)
            {
                if (input.Contains(item))
                {
                    numSpecialChar++;
                }
            }
            return numSpecialChar;
        }
        public static void CreatNewProfile()
        {
            // Instructions and control to create a new player profile
            Console.WriteLine("Create a password that contains at least: 1 uppercase letter, 1 lowercase letter, 1 special character.");

            Player.Password = Console.ReadLine();

            Validate(Player.Password);

            Console.WriteLine("\nEnter your Character's Name: ");

            Player.Name = Console.ReadLine();

            Console.WriteLine("\nEnter your Character's Class: \nChoose from Warrior, Rogue, Shaman, Cleric or Mage:");

            Player.Class = Console.ReadLine();

            Console.WriteLine("\nEnter your Character's Race: \nChoose from: Human, Kobold, Troll, Ogre, Elf, or Dawrf");

            Player.Race = Console.ReadLine();

            using (StreamWriter outFile = File.CreateText("PlayerProfile.txt"))
            {
                outFile.WriteLine(Player.Password);
                outFile.WriteLine(Player.Name);
                outFile.WriteLine(Player.Class);
                outFile.WriteLine(Player.Race);

                Console.WriteLine("\nYour profile has been created.");
            }
        }
    }
}
