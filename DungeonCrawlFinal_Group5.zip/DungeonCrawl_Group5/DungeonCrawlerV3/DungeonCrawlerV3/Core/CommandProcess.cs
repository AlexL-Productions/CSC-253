﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class CommandProcess:RandomNumber
    {
        public static bool DetermineCommand(string input)
        {
            Player player = new Player();
            RandomNumber rand = new RandomNumber();
            Mob enemy = new Mob();
            Combat combat = new Combat();

            string command;
            int encounterNum = rand.GetRandomNum(1, 7);

            if (input.ToLower() == "exit")
            {
                return true;
            }
            switch (input.ToLower())
            {
                case "rooms":
                    foreach (var obj in World.rooms)
                    {
                        Console.WriteLine(obj.Name);
                    }
                    return false;
                case "mobs":
                    foreach (var obj in World.mobs)
                    {
                        Console.WriteLine(obj.Name);
                    }
                    return false;
                case "weapons":
                    foreach (var obj in World.weapons)
                    {
                        Console.WriteLine(obj.Name);
                    }
                    return false;
                case "potions":
                    foreach (var obj in World.potions)
                    {
                        Console.WriteLine(obj.Name);
                    }
                    return false;
                case "treasure":
                    foreach (var obj in World.treasures)
                    {
                        Console.WriteLine(obj.Name);
                    }
                    return false;
                // player advances north 
                case "north":

                    if (enemy.CurrentLocation == encounterNum)
                    {
                        Console.WriteLine("Enemy monster encountered!!!\n=>");

                        enemy.isEncountered = true;

                        Console.WriteLine("What will you do?\nType 'flee' or 'combat'\n=>");

                        command = Console.ReadLine();

                        switch (command.ToLower())
                        {
                            case "flee":
                                Console.WriteLine("you fled from combat\n=>");
                                return false;

                            case "combat":
                                combat.BeginBattle(command);
                                Console.ReadLine();
                                return false;
                        }
                    }

                    if (World.players[0].CurrentLocation >= 5)
                    {
                        Console.WriteLine("Cant' go that way!!");
                    }
                    else
                    {
                        World.players[0].CurrentLocation += 1;
                    }
                    return false;

                // player advances south
                case "south":

                    if (enemy.CurrentLocation == encounterNum)
                    {
                        Console.WriteLine("Enemy monster encountered!!!\n=>");

                        enemy.isEncountered = true;

                        Console.WriteLine("What will you do?\nType 'flee' or 'combat'\n=>");

                        command = Console.ReadLine();

                        switch (command.ToLower())
                        {
                            case "flee":
                                Console.WriteLine("you fled from combat\n=>");
                                return false;
                            case "combat":
                                combat.BeginBattle(command);
                                Console.ReadLine();
                                return false;
                        }
                    }

                    if (World.players[0].CurrentLocation <= 0)
                    {
                        Console.WriteLine("Can't go that way!!");
                    }
                    else
                    {
                        World.players[0].CurrentLocation -= 1;
                    }
                    return false;
            }
            return false;
        }
    }
}
