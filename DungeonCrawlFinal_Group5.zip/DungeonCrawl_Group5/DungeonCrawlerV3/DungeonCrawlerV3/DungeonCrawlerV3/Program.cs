﻿/**
* 21 October 2018
* CSC 253
* Alex Lopez
* Module 3 Dungeon Crawler console game 
* that uses files to create objects for the game
* and stores player information in a file so the player
* can load their previous game data and continue from 
* last session
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;

namespace DungeonCrawlerV3
{
    class Program
    {
        static void Main(string[] args)
        {            
            ListBuilder.Build();
            WelcomeScreen.Welcome();
            Console.WriteLine(" => ");
            string password = Console.ReadLine();
            PlayerLogin.LoadProfile(password);

            bool exit = false;

            do
            {
                Console.WriteLine(" ");
                StandardMessages.DisplayMenu();
                Console.Write(" ");
                Console.WriteLine("You stand in the " + World.rooms[World.players[0].CurrentLocation].Name);
                Console.Write("=> ");
                string userInput = Console.ReadLine();
                Console.WriteLine(" ");
                exit = CommandProcess.DetermineCommand(userInput);


            } while (exit == false);
        }
    }
}
