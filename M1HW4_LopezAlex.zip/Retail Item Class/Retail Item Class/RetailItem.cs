﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail_Item_Class
{
    class RetailItem
    {
        // initiate the variables and it's accessors
        public string itemDescription { get; private set; }
        public int unitsOnHand { get; private set; }
        public double price { get; private set; }

        // constructor that accepts parameters
        public RetailItem(string item, int units, double p)
        {
            itemDescription = item;
            unitsOnHand = units;
            price = p;
        }
    }
}
