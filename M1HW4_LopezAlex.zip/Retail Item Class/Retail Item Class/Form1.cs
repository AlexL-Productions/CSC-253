﻿using System;
using System.Collections;
using System.Windows.Forms;
/**
* 9/7/2018
* CSC 253
* Alex Lopez
* This program displays the name, quantity, and price of items
*/
namespace Retail_Item_Class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // instantiate three RetailItem objects and pass arguments
            RetailItem[] items = {
                                    new RetailItem("Jacket", 12, 59.95),
                                    new RetailItem("Jeans", 40, 34.95),
                                    new RetailItem("Shirt", 20, 24.95)
                                 };

            // add a header to the listBox and add a space
            itemListBox.Items.Add("Description:" + "\tUnits:" + "\tPrice:");
            itemListBox.Items.Add("");

            // add the values of the array to the listBox
            foreach (RetailItem count in items)
            {
                itemListBox.Items.Add(count.itemDescription + "\t\t" +
                    count.unitsOnHand + "\t" + count.price);
            }     
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form 
            this.Close();
        }
    }
}
