﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 8/31/2018
* CSC 253
* Alex Lopez
* Award points for the amount of books purchased
*/
namespace Book_Club_Points
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitLabel_Click(object sender, EventArgs e)
        {
            // variables for books and reward points
            int booksPurchased;
            int rewardPoints = 0;

            // get the amount of books purchased and award points
            if (int.TryParse(booksTextBox.Text, out booksPurchased))
            {
                if (booksPurchased == 1)
                {
                    rewardPoints = 5;
                }
                if (booksPurchased == 2)
                {
                    rewardPoints = 15;
                }
                if (booksPurchased == 3)
                {
                    rewardPoints = 30;
                }
                if (booksPurchased >= 4)
                {
                    rewardPoints = 60;
                }

                // display the amount points earned
                pointsLabel.Text = rewardPoints.ToString();
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the program
            this.Close();
        }
    }
}
