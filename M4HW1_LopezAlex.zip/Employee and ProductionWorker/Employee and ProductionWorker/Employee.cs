﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class Employee
    {
        // Variables to hold the user's name and id number
        public string name { get; set; }
        public int number { get; set; }

        // Constructor 
        public Employee()
        {
            this.name = "";
            this.number = 0;
        }
    }
}
