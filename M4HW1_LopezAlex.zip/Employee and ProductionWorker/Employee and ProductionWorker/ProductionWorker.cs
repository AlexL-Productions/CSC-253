﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class ProductionWorker : Employee
    {
        // numeric variables for shift and hourly payrate 
        public int shiftNumber { get; set; }
        public decimal hourlyPayRate { get; set; }

        // Method to instantiate an employee object and get user input
        // Convert input from string to numeric values
        public void CreateEmployeeProfile()
        {
            ProductionWorker employee = new ProductionWorker();

            Console.WriteLine("Enter your full name: ");

            this.name = Console.ReadLine();

            Console.WriteLine("Enter your ID number: ");

            this.number = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your shift number (1 for Day, 2 for Night):");

            this.shiftNumber = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your hourly pay rate: ");

            this.hourlyPayRate = decimal.Parse(Console.ReadLine());
        }

        // Method that accepts an object and displays the values of its variables
        public void DisplayData(ProductionWorker x)
        {
            Console.WriteLine("\nProfile Created: \n\nName: {0} \nID Number: {1} \nShift Number: {2} \nHourly Pay Rate: {3}",
                x.name, x.number, x.shiftNumber, x.hourlyPayRate.ToString("c"));
        }
    }
}
