﻿/**
* 10/30/2018
* CSC 253
* Alex Lopez
* Employee and ProductionWorker Class
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate a ProductionWorker object
            ProductionWorker employees = new ProductionWorker();

            // Call the method to create the employee's profile
            employees.CreateEmployeeProfile();

            // Display the employees data
            employees.DisplayData(employees);

            // Keep the console open
            Console.ReadLine();
        }
    }
}
