﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class TeamLeader:ProductionWorker
    {
        // field variables
        public decimal monthlyBonus { get; set; }
        public decimal requiredHours { get; set; }
        public decimal hoursAttended { get; set; }

        // constructor
        public TeamLeader()
        {
            this.monthlyBonus = 0.0m;
            this.requiredHours = 0.0m;
            this.hoursAttended = 0.0m;
        }

        // Method that prompts the user for input
        // and stores them in the variables
        public void GetUserInput(TeamLeader leader)
        {
            Console.WriteLine("Enter the monthly bonus amount: ");
            leader.monthlyBonus = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter amount of training hours required: ");
            requiredHours = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of hours trained: ");
            hoursAttended = decimal.Parse(Console.ReadLine());
        }
    }
}
