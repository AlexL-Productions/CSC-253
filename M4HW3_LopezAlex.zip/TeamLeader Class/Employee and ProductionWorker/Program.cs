﻿/**
* 11/10/2018
* CSC 253
* Alex Lopez
* ShiftSupervisor Class
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    class Program
    {
        // Method that accepts instances and assigns 
        // the user input values to its variables
        private static void CreateEmployeeProfile(ShiftSupervisor supervisor, TeamLeader leader)
        {
            Console.WriteLine("Enter your full name: ");

             supervisor.Name = Console.ReadLine();

            Console.WriteLine("Enter your ID number: ");

            supervisor.Number = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your annual salary: ");

            supervisor.Salary = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Enter your annual bonus amount: ");

            supervisor.Bonus = decimal.Parse(Console.ReadLine());

            // call the TeamLeader's method to get input
            leader.GetUserInput(leader);
        }

        // Method that accepts an object and displays the values of its variables
        private static void DisplayData(ShiftSupervisor supervisor, TeamLeader leader)
        {
            Console.WriteLine("\nProfile Created: \n\nName: {0} \nID Number: {1} \nAnnual Salary: {2} \nAnnual Bonus: {3}",
                supervisor.Name, supervisor.Number, supervisor.Salary.ToString("c"), supervisor.Bonus.ToString("c"));
            Console.WriteLine("Monthly Bonus: {0} \nRequired hours of Training: {1} \nHours of Training Attended: {2}",
                leader.monthlyBonus.ToString("c"), leader.requiredHours, leader.hoursAttended);
        }

        public static void Main(string[] args)
        {
            // Instantiate objects
            ShiftSupervisor supervisor = new ShiftSupervisor();
            TeamLeader leader = new TeamLeader();

            // Call the local method to create the employee's profile
            CreateEmployeeProfile(supervisor, leader);

            // Display the employees data
            DisplayData(supervisor, leader);

            // Keep the console open
            Console.ReadLine();
        }
    }
}
