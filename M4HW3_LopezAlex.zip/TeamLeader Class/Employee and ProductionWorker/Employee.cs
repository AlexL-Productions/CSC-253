﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    public class Employee
    {
        // Variables to hold the user's name and id number
        private string _name;
        private int _number;

        // Constructor 
        public Employee()
        {
            this._name = "";
            this._number = 0;
        }
        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        
        // Number property
        public int Number
        {
            get { return _number; }
            set { _number = value; }
        }
    }
}
