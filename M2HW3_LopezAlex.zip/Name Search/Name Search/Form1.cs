﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/**
* 10/4/2018
* CSC 253
* Alex Lopez
* This program prompts the user to enter a name to
* see if its among the popular names in the US
*/

namespace Name_Search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
                // initiate two lists to store text from the file
                // one for boy names and one for girl names
                List<string> boyNames = new List<string>();
                List<string> girlNames = new List<string> ();
                
                // variables to store text, set size of the List, and step through loops
                string readNames;
                int size = 200;
                int index = 0;

                // open the files
                StreamReader inFile = File.OpenText("BoyNames.txt");
                StreamReader inFile2 = File.OpenText("GirlNames.txt");
                
                // read the files and store the values in the Lists
                while(!inFile.EndOfStream)
                {
                    readNames = inFile.ReadLine();
                    boyNames.Add(readNames);
                    readNames = inFile2.ReadLine();
                    girlNames.Add(readNames);
                }

                // Search through the list and compare it's values to the user's input
                while(index < size)
                {
                    if (boyNames[index] == nameTextBox.Text)
                    {
                        label1.Text = "That name IS in the list";
                        break;
                    }
                    else
                    {
                        label1.Text = "that name is NOT in the list";
                    }
                    if (girlNames[index] == nameTextBox.Text)
                    {
                        label1.Text = "That name IS in the list";
                        break;
                    }             
                    else
                    {
                        label1.Text = "That name is Not in the list";
                    }

                    index++;
                }
            }
            // exception
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }      
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
