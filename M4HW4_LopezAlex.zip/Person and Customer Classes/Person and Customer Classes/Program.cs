﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * 11/10/2018
 * CSC 253
 * Alex Lopez
 * Person and Customer Class
 * */
namespace Person_and_Customer_Classes
{
    class Program
    {
        // Method to get the customers input
        public static void GetCustomerData(Customer person)
        {
            string answer;

            Console.WriteLine("Enter your name: ");
            person.name = Console.ReadLine();
            Console.WriteLine("Enter your address: ");
            person.address = Console.ReadLine();
            Console.WriteLine("Enter your phone number: ");
            person.phoneNumber = Console.ReadLine();

            Console.WriteLine("Would you like to be in the Mailing List? ");
            answer = Console.ReadLine();

            // validate customers reply
            switch (answer.ToLower())
            {
                case "no":
                    Console.WriteLine("You will not be in the mailing list.");
                    person.reply = false;
                    break;
                case "yes":
                    Console.WriteLine("You will be added to the list.");
                    person.reply = true;
                    break;
            }
        }

        // Dipslay the customers information to the console
        public static void DisplayData(Customer person)
        {
            Console.WriteLine("\nName: {0} \nAddress: {1} \n Phone #: {2} \nMailing List? {3}",
                                person.name, person.address, person.phoneNumber, person.reply);
        }
   
        static void Main(string[] args)
        {
            // Instantiate a Customer object
            Customer person = new Customer();

            // Get customer's data
            GetCustomerData(person);

            // Display information
            DisplayData(person);

            Console.ReadLine();
        }
    }
}
