﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_and_Customer_Classes
{
    public class Customer:Person
    {
        // Field
        public int customerNumber { get; set; }
        public bool reply { get; set; }

        // Constructor
        public Customer()
        {
            customerNumber = 0;
        }
    }
}
