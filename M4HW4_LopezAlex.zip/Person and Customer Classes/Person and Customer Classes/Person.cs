﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_and_Customer_Classes
{
    public class Person
    {
        // Field
        public string name { get; set; }
        public string address { get; set; }
        public string phoneNumber { get; set; }

        // Constructor
        public Person()
        {
            name = "";
            address = "";
            phoneNumber = "";
        }
    }
}
