﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 8/31/2019
* CSC 253
* Alex Lopez
* This program will double your
* pay for every day you work
*/

namespace Pennies_for_Pay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // variables for total pay and days worked
            int daysWorked;
            double startingPay = 0.5;

            // get the amount of days worked
            daysWorked = int.Parse(DaysTextBox.Text);

            // double the pay for every day worked
            for (int i = 0; i < daysWorked; i++)
            {
                startingPay *= 2;
            }
            // display the currency value to the label
            startingPay /= 100;
            TotalPayLabel.Text = startingPay.ToString("c");
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // close the program
            this.Close();
        }
    }
}
