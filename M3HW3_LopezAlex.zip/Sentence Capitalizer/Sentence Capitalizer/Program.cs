﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
/**
* 10/25/2018
* CSC 253
* Alex Lopez
* Sentence Capitalizer
*/
namespace Sentence_Capitalizer
{
    class Program
    {
        // pass string to method and capitalize the first letter of strings 
        public static void CapitalizeSentence(string str)
        {
            str = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str);

            // display to console
            Console.Write(str);
        }
        static void Main(string[] args)
        {
            try
            {
                // get input string
                string str = Console.ReadLine();

                // call method to capitalize each letter of strings
                CapitalizeSentence(str);

                // keep the console open
                Console.Read();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
