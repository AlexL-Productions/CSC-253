﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 10/26/2018
* CSC 253
* Alex Lopez
* Morse Code Converter
*/
namespace Morse_Code_Converter
{
    class Program
    {
        public static void Main(string[] args)
        {
            //char variable to hold input subscript
            char c;

            // Dictionary of Characters and morse code translations
            Dictionary<char, string> morseCode = new Dictionary<char, string>()
            {
                {'A', ".-" },{'B',"-..." },{'C',"-.-."},{'D',"-.."},{'E',"." },
                {'F',"..-."},{'G',"--."},{'H',"...."},{'I',".."},{'J',".---"},
                {'K',"-.-"},{'L',".-.."},{'M',"---"},{'N',"-."},{'O',"---"},
                { 'P',".--."},{'Q',"--.-"},{'R',".-."},{'S',"..."},{'T',"-"},
                { 'U',"..-"},{'V',"..-" },{'W',".--" },{'X',"-..-"},{'Y',"-.--" },
                {'Z',"--.."},{' '," " },{',',"--..--" },{'.',".-.-.-" },{'?',"..--.."},
                {'0',"-----" },{'1',".----" },{'2',"..---" },{'3',"...--" },{'4',"....-" },
                {'5',"....." },{'6',"-...." },{'7',"--..." },{'8',"---.." },{'9',"----." },
            };

            Console.WriteLine("enter anything and translate to Morse Code: ");
            
            // get user input 
            string input = Console.ReadLine().ToUpper();

            // determine whether input is found in the Dictionary
            for(int i = 0; i < input.Length; i++)
            {
                // get the first character of input
                c = input[i];   

                if(morseCode.ContainsKey(c))
                {
                    Console.Write("{0}{1} ", input[i], morseCode[c]);
                }
            }
            // keep the console open
            Console.Read();          
        }
    }
}
