﻿using System;
using System.Collections;
using System.Windows.Forms;
/**
* 9/12/2018
* CSC 253
* Alex Lopez
* this program opens a file and displays its contents in a listBox
*/
namespace Retail_Item_Class
{
    public partial class Form1 : Form
    {
        // initiate the ArrayList
        ArrayList itemList = new ArrayList();

        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // instantiate three RetailItem objects and pass arguments
            RetailItem[] items = {
                                    new RetailItem("Jacket", 12, 59.95),
                                    new RetailItem("Jeans", 40, 34.95),
                                    new RetailItem("Shirt", 20, 24.95)
            };

            // add the objects to the list
            itemList.Add(items);

            // add a header to the listBox and add a space
            itemListBox.Items.Add("Description:" + "\tUnits:" + "\tPrice:");
            itemListBox.Items.Add("");

            // add the object's values to the listBox
            foreach (RetailItem count in items)
            {
                itemListBox.Items.Add(count.itemDescription + "\t\t" +
                    count.unitsOnHand + "\t" + count.price);
            }     
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form 
            this.Close();
        }
    }
}
