﻿/**
* 30 September 2018
* CSC 253
* Group 5
* Group Members: Rashad Henry, Alex Lopez
* Program description
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawler
{
    class Program
    {
        static void Main(string[] args)
        {
            // Title screen to welcome the new player
            Console.WriteLine("===============================\nWELCOME TO THE DUNGEON CRAWLER (By Rashad Henry and Alex Lopez)\n===============================");

            // Create arrays for 5 rooms, 4 weapons, 2 potions, and 3 treasures
            string[] rooms = new string[] { "Entrance", "Great Hall", "Laboratory", "Library", "Dormitory" };
            string[] weapons = new string[] { "Sword", "Bow", "Axe", "Dagger" };
            string[] potions = new string[] { "Healing Potion", "Mana Potion" };
            string[] treasure = new string[] { "Gold", "Gems", "Crystals" };

            // Create a two list one for 4 items and one for 5 mobs
            List<string> itemsList = new List<string>(new string[] { "Boots of Haste", "Robe of the Magi", "Stout Shield", "Map" });
            // I'm assuming Mobs is for enemeies, monsters?
            List<string> mobList = new List<string>(new string[] { " Dragons", "Orcs", "Elders", "Guardians", "Golems" });

            // Display basic commands to the player for action pass welcome screen
            Console.WriteLine("Enter one of the following commands: (Or to quit the game type 'q')\nRooms\nWeapons\nPotions\nTreasures\nItems\nMob\n\n");

            // Variable to hold playerInput
            string playerInput;

            // Read the player input and display the appropriate array
            while ((playerInput = Console.ReadLine()) != "q")
            {
                // Display the Room options
                if (playerInput == "Rooms")
                {
                  
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine(rooms[i]);
                    }

                    Console.WriteLine("\nTo enter a room, type one of the following: (Or type 'q' to exit)\n" +
                        "'nw' to move north West\n" +
                        "'ne' to move North East\n" +
                        "'w' to move  West\n" +
                        "'e' to move East\n" +
                        "'s' to move South");

                    string direction;

                    // Read the player's input and move to the appropriate room
                    while ((direction = Console.ReadLine()) != "q")
                    {
                        if (direction == "nw")
                        {
                            Console.WriteLine("You're in the Laboratory Room");
                        }

                        if (direction == "ne")
                        {
                            Console.WriteLine("You're in the Great Hall room");
                        }

                        if (direction == "w")
                        {
                            Console.WriteLine("You're in the Dormitory room");
                        }

                        if (direction == "e")
                        {
                            Console.WriteLine("You're in the Library room");
                        }

                        if (direction == "s")
                        {
                            Console.WriteLine("You're in the Entrance room");
                        }
                    }
                }
                
                // Display the Weapons
                if (playerInput == "Weapons")
                {
                    for (int i = 0; i < weapons.Length; i++)
                    {
                        Console.WriteLine(weapons[i]);
                    }
                    Console.WriteLine();
                }

                // Display the Potions 
                if (playerInput == "Potions")
                {
                    for (int i = 0; i < 2; i++)
                    {
                        Console.WriteLine(potions[i]);
                    }
                    Console.WriteLine();
                }

                // Display the Treasures 
                if (playerInput == "Treasures")
                {
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine(treasure[i]);
                    }
                    Console.WriteLine();
                }

                // Display the Items in the inventory
                if (playerInput == "Items")
                {
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine(itemsList[i]);
                    }
                    Console.WriteLine();
                }

                // Display the other characters
                if (playerInput == "Mob")
                {
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine(mobList[i]);
                    }
                    Console.WriteLine();
                }
            }
            // Keep the console displayed
            Console.ReadLine();
        }
        
    }
}
        
    

    

    

